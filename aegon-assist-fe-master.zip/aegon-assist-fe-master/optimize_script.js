
var fs = require('fs');
var path = 'dist/aegon/index.html';
function readModuleFile(path, callback) {
  try {
    var filename = path;
    fs.readFile(filename, 'utf8', callback);
  } catch (e) {
    callback(e);
  }
}
function replaceAll(str, find, replace) {
  return str.replace(new RegExp(find, 'g'), replace);
}
readModuleFile(path, function (err, words) {
  let newResource = replaceAll(words, '<script type="text/javascript"', '<script type="text/javascript" defer');
  newResource = newResource.replace('<link rel="stylesheet"', '<link rel="stylesheet" defer')
  fs.writeFileSync('dist/aegon/index.html', newResource)
})