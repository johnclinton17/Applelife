import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import Analytics from '@aws-amplify/analytics';
import Amplify from 'aws-amplify';
import Auth from '@aws-amplify/auth';
import { AppModule } from './app/app.module';
import { environment } from './environments/environment';
if (environment.production) {
  enableProdMode();
}
Amplify.configure({
  Auth: {
    userPoolId: environment.userPoolId,
    userPoolWebClientId:  environment.userPoolWebClientId,
  }
});
const amplifyConfig = {
  Auth: {
    identityPoolId: environment.identityPoolId,
    region: environment.region
  }
}
//Initialize Amplify
Auth.configure(amplifyConfig); 
const analyticsConfig = {
  AWSPinpoint: {
        appId: environment.pinpoint ,
        region: environment.region,
        mandatorySignIn: false,
  }
}
Analytics.configure(analyticsConfig)
Analytics.autoTrack('session', {
    enable: true,
});
Analytics.autoTrack('pageView', {
    enable: true,
});
platformBrowserDynamic().bootstrapModule(AppModule)
  .catch(err => console.error(err));
