/*
 * aegonlife - v1.0.0 - 2019
 * @author aegonlife Insurance
 * otp.component.ts
 * Description: Otp authentication of user
 * Copyright (c) 2019 aegonlife Insurance
 */

import { Component, OnInit, Renderer2 } from '@angular/core';
import { ApiService } from './../api/api.service';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { DesktophomeComponent } from '../desktophome/desktophome.component';
import Analytics from '@aws-amplify/analytics';
declare var $: any
@Component({
  selector: 'app-otp',
  templateUrl: './otp.component.html'
})
export class OtpComponent implements OnInit {

  screenFlag: boolean = false;
  errorFlag = false;
  errorNumberFlag = false;
  otpText : string;
  public user_name: string;
  // animated veriable declearation
  public lottieConfig: Object;
  public lottieConfigerror: Object;
  private anim: any;
  private erroranim: any;
  optstart: boolean = false;
  public otpstart: boolean = false;
  private phones_ = new BehaviorSubject('');
  public phones = this.phones_.asObservable();
  errorMessage: string;
  successMessage: string;
  successFlag = false;
  requestType: string;
  disablestatus : boolean = false;
  otpMessageForAction: string;
  constructor(private ApiService: ApiService, public home: DesktophomeComponent, private router: Router, private renderer: Renderer2) {
    // animation configs
    this.lottieConfig = this.ApiService.animationConfig('assets/icons/animation-json/1708-success.json', false);
    this.lottieConfigerror = this.ApiService.animationConfig('assets/icons/animation-json/4903-failed.json', false);
    this.renderer.addClass(document.body, 'otp');
  }
  ngOnDestroy() {
    this.renderer.removeClass(document.body, 'otp');
  }
  handleAnimation(anim: any) {
    this.anim = anim;
  }
  handleErrorAnimation(erroranim: any) {
    this.erroranim = erroranim;
  }
  successAnimation() {
    this.anim.play();
  }
  ngOnInit() {
    this.requestType = localStorage.getItem('event')
    if(localStorage.getItem('action')){
      let otpMessage = localStorage.getItem('action')
      if(otpMessage == 'surrender'){
        this.otpMessageForAction = 'Enter OTP sent to your registered mobile or email address.';
      }
      if(otpMessage == 'mobile'){
         this.otpMessageForAction = 'Enter OTP sent to your new mobile number.';
      }
      if(otpMessage == 'email'){
        this.otpMessageForAction = 'Enter OTP sent to your new email address.';
      }
     
    }
    
  }
  async validateotp(event) {
    let event_name = localStorage.getItem('action')
   
    var otp = this.otpText;
    if (otp.length == 6 && !this.optstart) {
      $('input').blur();
      this.disablestatus = true;
      var updateObject = this.home.setObject();
      updateObject.otp = otp;
      this.otpstart = true;
      this.otpstart = false;
      try {
        if (this.requestType == 'contact') {
          this.ApiService.apirequest('/endorsements/contacts', updateObject).subscribe(data => {
            let response = data.json();
            if (response.status) {
              this.home.setrequestId(response.requestId);
              this.anim.play();
              this.ApiService.destroySuccess(2500).then(() => { this.anim.stop(); this.home.setFlag('feedback') }); 
              Analytics.record({ name: event_name +'_success', attributes: { mobile: localStorage.getItem('visit') } });
            }
            else {
              this.otpText = '';
              this.errorMessage =  response.message;
              this.errorFlag = true;
              this.disablestatus = false;
              this.ApiService.destroySuccess(3000).then(() => { this.errorFlag = false; });
              Analytics.record({ name: event_name + '_failed', attributes: { mobile: localStorage.getItem('visit') } });
            }  
          })
        }
    
        if (this.requestType == 'surrender') {
          updateObject.otp = otp;
          updateObject.type = 'confirm';
          this.ApiService.apirequest('/policy/cancellation', updateObject).subscribe(data => {
            var response = data.json();
            if (response.message) {
              this.errorMessage = data.json().message;
              this.errorFlag = true;
              this.disablestatus = false;
              this.otpText = '';
              this.ApiService.destroySuccess(3500).then(() => { this.errorFlag = false; });
              Analytics.record({ name: 'surrender_failed', attributes: { mobile: localStorage.getItem('visit') } });
            }
            else {
              this.home.setrequestId(response.data.desc);
              this.anim.play();
              this.ApiService.destroySuccess(2500).then(() => { this.anim.stop(); this.home.setFlag('feedback') });
              Analytics.record({ name: 'surrender_success', attributes: { mobile: localStorage.getItem('visit') } });
            }
          })
        }
      }
      catch (err) {
        this.errorMessage = "Please enter a valid OTP";
        this.errorFlag = true;
        this.disablestatus = false;
        this.otpText = '';
        this.ApiService.destroySuccess(3000).then(() => { this.errorFlag = false; });
      }
    }
   
  }
  //  resend otp 
  resentotp() {
    let event_trigger = localStorage.getItem('action')
    this.otpText = '';
      var otpobject = this.home.setObject()
      if (this.requestType == 'contact') {
        if (otpobject.updatetype == 'mobile') {
          if (otpobject.updatedata.mobile.length > 9) {
            this.updateContactRequest('send', otpobject.updatetype, '+91'+otpobject.updatedata.mobile);
            Analytics.record({ name: 'mobile_update_otp_resent', attributes: {mobile: localStorage.getItem('visit') } });
          }
          else {
            this.errorMessage = "Unable to resend OTP";
            this.errorFlag = true;
            this.ApiService.destroySuccess(3000).then(() => { this.errorFlag = false; });
          }
        }
        if (otpobject.updatetype == 'email') {
          if (otpobject.updatedata.email) {
            this.updateContactRequest('send', otpobject.updatetype, otpobject.updatedata.email);
            Analytics.record({ name: 'email_update_otp_resent', attributes: { mobile: localStorage.getItem('visit') } });
          }
          else {
            this.errorMessage = "Unable to resend OTP";
            this.errorFlag = true;
            this.ApiService.destroySuccess(3000).then(() => { this.errorFlag = false; });
          }
        }
        
      }
      else {
        otpobject.type = 'mobile';
        this.ApiService.apirequest('/policy/cancellation', otpobject.updatedata).subscribe(data => {
          let response = data.json();
          if (response.status) {
            this.successMessage = "OTP has been resent";
            this.successFlag = true;
            this.ApiService.destroySuccess(3000).then(() => { this.successFlag = false; });
            Analytics.record({ name: 'nominee_update_otp_resent', attributes: {mobile: localStorage.getItem('visit') } });
          }
          else {
            this.errorMessage = response.message;
            this.errorFlag = true;
            this.ApiService.destroySuccess(3000).then(() => { this.errorFlag = false; });
          }
        })
      }
  }
// send otp for mobile
  updateContactRequest(reqtype, updatetype, data) {
    this.ApiService.apirequest('/endorsements/contacts', { updatedata: data, reqtype: reqtype, updatetype: updatetype,  policyNumber : this.home.setObject().policyNumber  }).subscribe(data => {
      let response = data.json();
      if (response.status) {
        this.successMessage = "OTP has been resent";
        this.successFlag = true;
        this.ApiService.destroySuccess(3000).then(() => { this.successFlag = false; });
      }
      else {
        this.errorMessage = response.message;
      this.errorFlag = true;
      this.ApiService.destroySuccess(3000).then(() => { this.errorFlag = false; });
      }
    }, err => {
      this.errorMessage = "Oops! Something went wrong.";
      this.errorFlag = true;
      this.ApiService.destroySuccess(3000).then(() => { this.errorFlag = false; });
    })
  }
  // only number will accept
  validateNumber(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
}
