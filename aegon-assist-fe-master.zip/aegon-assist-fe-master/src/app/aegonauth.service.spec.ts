import { TestBed } from '@angular/core/testing';

import { AegonauthService } from './aegonauth.service';

describe('AegonauthService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AegonauthService = TestBed.get(AegonauthService);
    expect(service).toBeTruthy();
  });
});
