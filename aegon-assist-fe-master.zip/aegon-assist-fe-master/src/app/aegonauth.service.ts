import { Injectable, Inject } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { Auth } from 'aws-amplify';
import { CognitoUser } from 'amazon-cognito-identity-js';


@Injectable({
  providedIn: 'root'
})
export class AegonauthService {

  private cognitoUser: CognitoUser & { challengeParam: { phone_number: string, email: string } };
  // Get access to window object in the Angular way
  private window: Window;
  constructor(@Inject(DOCUMENT) private document: Document) {
    this.window = this.document.defaultView;
  }
  public async signIn(user_name: string) {
    this.cognitoUser = await Auth.signIn(user_name);
  }
  public async signOut() {
    await Auth.signOut({ global: true });
  }
  
  public async answerCustomChallenge(answer: string) {
    this.cognitoUser = await Auth.sendCustomChallengeAnswer(this.cognitoUser, answer);
   
    if (this.cognitoUser.getSignInUserSession()) {
      var tokendata = await Auth.currentSession();
      var authcheck = this.isAuthenticated();
     
      if (tokendata && authcheck) {
        var expirationMS = 350 * 60 * 1000;
        var record = { timestamp: new Date().getTime() + expirationMS }
        localStorage.setItem('expirecheck', JSON.stringify(record));
        localStorage.setItem('accessToken', tokendata.getAccessToken().getJwtToken());
        localStorage.setItem('secretToken', tokendata.getIdToken().getJwtToken());
       
      }
      return authcheck;
    }
    return false
  }
  

  public async getPublicChallengeParameters() {
    return this.cognitoUser.challengeParam;
  }
  public async signUp(user_name: string) {
    
    const params = {
      username: user_name,
      password: this.getRandomString(30),
      attributes: {}
    };
    return await Auth.signUp(params);
  }
  public async confirmSignUp(user_name: string, otp: string) {
    return await Auth.confirmSignUp(user_name, otp)
  }
  private getRandomString(bytes: number) {
   
   var passstring =  Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15) + '@A'+Math.floor(Math.random()*(999-100+1)+100);
    return passstring;
  }
  
  private intToHex(nr: number) {
    return nr.toString(16).padStart(2, '0');
  }
  public async isAuthenticated() {
    try {
      await Auth.currentSession();
      return true;
    } catch (err) {
      return false;
    }
  }
  public async currentSessiondata() {
    await Auth.currentAuthenticatedUser();
  }
  public async getUserDetails() {
    if (!this.cognitoUser) {
      this.cognitoUser = await Auth.currentAuthenticatedUser();
    }
    return await Auth.userAttributes(this.cognitoUser);
  }
}

