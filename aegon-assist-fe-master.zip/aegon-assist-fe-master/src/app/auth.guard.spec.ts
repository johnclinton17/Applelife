import { TestBed, async, inject } from '@angular/core/testing';
import { Router, RouterModule } from '@angular/router';
import { AuthGuard } from './auth.guard';
import { APP_BASE_HREF } from '@angular/common';
import { AppRoutingModule } from './app-routing.module';
describe('AuthGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AuthGuard,{ provide: APP_BASE_HREF, useValue : '' }],
      imports: [ RouterModule,AppRoutingModule]
    });
  });

  it('should ...', inject([AuthGuard], (guard: AuthGuard) => {
    expect(guard).toBeTruthy();
  }));
});
