/*
 * aegonlife - v1.0.0 - 2019
 * @author aegonlife Insurance
 * update-profile.component.ts
 * Description: update the email and contact number
 * Copyright (c) 2019 aegonlife Insurance
 */
// import packages
import { Component, OnInit} from '@angular/core';
import { ApiService } from './../api/api.service';
import { AppComponent } from '../app.component';
import { DesktophomeComponent } from '../desktophome/desktophome.component';
import Analytics from '@aws-amplify/analytics';

@Component({
  selector: 'app-update-profile',
  templateUrl: './update-profile.component.html'
})
export class UpdateProfileComponent implements OnInit {
  // veriable declearation
  public lottieConfig: Object;
  public lottieConfigSuccess: Object;
  private anim: any;
  userDetails: any;
  policyDetails: any;
  otpFlag: boolean = false;
  mobileNo: string;
  emailId: string;
  mobile_no: any;
  errorNumberFlag = false;
  updatetype : string;
  errorMsg :string;
  updateObj = {
    "mobile": '',
    "policyNumber": '',
  };
  constructor(private appComponent : AppComponent,public home:DesktophomeComponent,private ApiService: ApiService) {
    // animation configs
    this.lottieConfig = this.ApiService.animationConfig('assets/icons/animation-json/input-tick.json', false);
    this.lottieConfigSuccess = this.ApiService.animationConfig('assets/icons/animation-json/1708-success.json', false);
  }
  // handle animation
  handleAnimation(anim: any): void {
    this.anim = anim;
  }
 
  // To check 10 digits and showing check animation
  textMobile(evernt: any): void {
    var target = event.srcElement;
    if (this.mobile_no) {
      var textLength = this.mobile_no.length;
    }
    if (textLength === 10) {
      this.anim.play();
    }
    else {
      this.anim.stop();
    };
  }
  ngOnInit() {
    
    this.userDetails = this.home.userdata();
    this.policyDetails = this.home.policydata();
    this.updateObj.policyNumber = this.policyDetails.policyNumber;
   // get user deatail
    this.emailId =  this.userDetails.email;
    this.mobileNo =  this.userDetails.mobile;
   
  }
  
  //  check for only numbers
  onlyNumber(event): boolean {
    return this.ApiService.onlyNumber(event);
  }
  
  //  check for numeric

  // to send otp on mobile and email
  updateProfile(type) {
    this.appComponent.loaderfunction(true);
     this.updatetype = type;
      if (this.mobile_no.length > 9) {
        this.updateObj.mobile = this.mobile_no;
        this.updateRequest('send', type);
      }
      else {
        this.appComponent.loaderfunction(false);
        this.errorNumberFlag = true;
        this.errorMsg = 'Your mobile number is invalid.'
        this.ApiService.destroySuccess(3000).then(() => { this.errorNumberFlag = false; });
      }
  }
  // to send otp mobile email
  updateRequest(reqtype, updatetype) {
    
   var reqdata =  { reqtype: reqtype, updatetype: updatetype,updatedata : '+91'+this.mobile_no, policyNumber : this.updateObj.policyNumber  };
    this.ApiService.apirequest('/endorsements/contacts',reqdata).subscribe(data => {
      let response = data.json();
      if (response.status) {
        this.home.setFlag('otp');
        Analytics.record({ name: 'update mobile', attributes: { mobile: this.mobile_no } });
        localStorage.setItem('event','contact');
        this.home.getObject({ "updatedata" : this.updateObj ,mobile_no : this.mobile_no, policyNumber : this.updateObj.policyNumber ,"reqtype":'verify', "updatetype":'mobile', "otp": '' });
      }
      else {
        this.errorNumberFlag = true;
        this.errorMsg = response.message;
        this.ApiService.destroySuccess(3000).then(() => { this.errorNumberFlag = false; });
      }
      this.appComponent.loaderfunction(false);
    }, err => {
      this.errorNumberFlag = true;
      this.appComponent.loaderfunction(false);
      this.errorMsg =  "Session Timeout Please sign in again.";
      this.ApiService.destroySuccess(3000).then(() => { this.errorNumberFlag = false; });
    })
  }
  backtoprofile() {
    this.otpFlag = false;
  }
}
