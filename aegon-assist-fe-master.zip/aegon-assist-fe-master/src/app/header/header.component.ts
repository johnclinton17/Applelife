/*
 * aegonlife - v1.0.0 - 2019
 * @author aegonlife Insurance
 * header.component.ts
 * Description: Menu 
 * Copyright (c) 2019 aegonlife Insurance
 */
//import all dependency file
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ResponsiveService } from '../responsive.service';
import { DesktophomeComponent } from '../desktophome/desktophome.component';
import { AegonauthService } from '../aegonauth.service';
import Analytics from '@aws-amplify/analytics';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html'
})
export class HeaderComponent implements OnInit {
  public isMobile: Boolean;
  mobileNumber : string;
  clientName: string;
  alignment : string;
  constructor(public home:DesktophomeComponent,private auth: AegonauthService, private router: Router, private responsiveService: ResponsiveService) {  }
  ngOnInit() {
   
    // resize event
    this.onResize();// resize event
    setTimeout(() => {
      this.getprofile();
     }, 2000);
    this.responsiveService.checkWidth();
  }
  getprofile()
  {
    var userdata = this.home.userdata();
    if(userdata.firstName)
    {
     this.clientName = userdata.firstName; 
     this.mobileNumber = userdata.mobile;
    }
    else{
      this.ngOnInit();
    }
  }
  // resize fucntion
  onResize(): void  {
    this.responsiveService.getMobileStatus().subscribe(isMobile => {
      this.isMobile = isMobile;
      if(this.isMobile){
        this.alignment = 'left'
      }
      else{
        this.alignment = 'right';
      }
     
    });
  }
  languagecall(): void  {
    var x = document.getElementById("myDIV");
    if (x.innerText === "English") {
      x.innerText = "हिंदी";
    } else {
      x.innerText = "English";
    }
  }
  logOut(): void  {
    this.auth.signOut();
    localStorage.removeItem('accessToken');
    localStorage.removeItem('secretToken');
    localStorage.removeItem('expirecheck');
    localStorage.removeItem('partyid');
    localStorage.removeItem('message');
    this.router.navigate(['/login']);
    Analytics.record({ name: 'Track Requests', attributes: { mobile: this.mobileNumber } });
  }

  surrenderModal(): void {
    this.home.mobileModal();
    this.home.setFlag('surrender')
  }
  trackModal(): void {
    this.home.mobileModal();
    this.home.setFlag('track')
    Analytics.record({ name: 'Logout', attributes: { mobile: this.mobileNumber } });
  }

  support():void {
    Analytics.record({ name: 'Support', attributes: { mobile: this.mobileNumber } });
  }

}
