/*
 * aegonlife - v1.0.0 - 2019
 * @author aegonlife Insurance
 * otp.component.ts
 * Description: JWT authentication to authenticate user
 * Copyright (c) 2019 aegonlife Insurance
 */
import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  constructor(private router: Router) { }
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    if (localStorage.getItem('expirecheck')  && localStorage.getItem('accessToken') && localStorage.getItem('secretToken')) {
      var record = JSON.parse(localStorage.getItem('expirecheck'));
      if (new Date().getTime() > record.timestamp) {
        localStorage.removeItem('accessToken');
        localStorage.removeItem('secretToken');
        localStorage.removeItem('expirecheck')
        this.router.navigate(['']);
        return false;
      }
      else {

        return true;
      }
    }
    // not logged in so redirect to login page with the return url
    this.router.navigate(['']);
    return false;
  }
}
