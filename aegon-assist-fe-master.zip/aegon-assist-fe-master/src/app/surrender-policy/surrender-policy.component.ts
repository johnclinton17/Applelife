/*
 * aegonlife - v1.0.0 - 2019
 * @author aegonlife Insurance
 * surrender.component.ts
 * Description: surrender Policy
 * Copyright (c) 2019 aegonlife Insurance
 */
import { Component, OnInit, HostListener, ElementRef, ViewChild } from '@angular/core';
import { ApiService } from './../api/api.service';
import { DesktophomeComponent } from '../desktophome/desktophome.component';
import * as moment from 'moment';
import { AppComponent } from '../app.component';
import Analytics from '@aws-amplify/analytics';
declare let $: any;


@Component({
  selector: 'app-surrender-policy',
  templateUrl: './surrender-policy.component.html'
})
export class SurrenderPolicyComponent implements OnInit {
  inBounds = true;
  position;
  edge = {
    top: true,
    bottom: true,
    left: true,
    right: true
  };
  userDetails: any;
  mobileNo: number;
  emailId: string;
  firstName: string;
  lastName: string;
  name: string;
  policyDetail: any;
  policyName: string;
  policyNumber: string;
  sumAssured: string;
  data: any;
  surrenderFlag = false;
  difference: any;
  freelookPeriod: string;
  bottomflag = true;
  errorFlag: false;
  errormsg : string;
  @ViewChild("block", { read: ElementRef }) block: ElementRef;
  policystatus: any;
  @HostListener('touchmove', ['$event'])
  handleWheelEvent(event) {
    event.preventDefault();
  }
  constructor(public appComponent: AppComponent, private ApiService: ApiService, public home: DesktophomeComponent) {
  }
  ngOnInit() {
    this.appComponent.startLoader();
    this.userDetails = this.home.userdata();
    this.policyDetail = this.home.policydata();
    let before = moment(this.policyDetail.issueDate);
    let now = moment();
    this.difference = now.diff(before, 'days');
  
    this.freelookPeriod = this.policyDetail.freelookPeriod;
    
  //  console.log(this.difference);
   // console.log(parseInt(this.freelookPeriod) == parseInt(this.difference));
   
    if ( parseInt(this.freelookPeriod) >= parseInt(this.difference)) {
      this.surrenderFlag = true;
    }
    else {
      this.surrenderFlag = false;
    }
    this.sumAssured = this.policyDetail.coverages[0].sumAssured || '';
    this.policystatus = this.policyDetail.policyStatus.status;
    this.policyName = this.policyDetail.product.name;
    this.policyNumber = this.policyDetail.policyNumber;
    this.firstName = this.userDetails.firstName;
    this.lastName = this.userDetails.lastName;
    this.mobileNo = this.userDetails.mobile;
    this.emailId = this.userDetails.email;
    if (this.userDetails.lastName != null) {
      this.name = this.userDetails.firstName + ' ' + this.userDetails.lastName;
    } else {
      this.name = this.userDetails.firstName;
    }
  }
  success(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
  // adding and removing class to card
  addClass(): void {
    document.getElementById('textpara').classList.add("mystyle");
  }
  removeClass(): void {
    document.getElementById('textpara').classList.remove("mystyle");
  }
  // adding and removing class to card
  // Get the modal
  // When the user clicks the button, open the modal 
  openAlert(): void {
    let modal = document.getElementById("myModal");
    modal.style.display = "block";
  }
  // When the user clicks on <span> (x), close the modal
  closeAlert(): void {
    let modal = document.getElementById("myModal");
    modal.style.display = "none";
  }
  // surrender error alert
  erroropenAlert(): void {
    let errormodal = document.getElementById("myModalError");
    errormodal.style.display = "block";
  }
  errorcloseAlert(): void {
    this.cardReset();
    let errormodal = document.getElementById("myModalError");
    errormodal.style.display = "none";
  }
  // resetting the card
  cardReset(): void {
    this.position = { x: 0, y: 0 }
    this.chagnedetected = true;
    this.closeAlert();
    $(".hide-move-div h5, .hide-when-slide").css({ "opacity": "1", "transition": ".5s linear" });
    Analytics.record({ name: 'Keep_me_Insured', attributes: { mobile: localStorage.getItem('visit') }});
  }
  // deleting the card
  deleteCard(): void {
    this.closeAlert();
    this.appComponent.loaderfunction(true);
    var today = new Date();
    let obj = {
      "comment": "null",
      "reason": "FINANCIAL_DIFFICULTY", // Predefined Reasons forcancellation
      "requestedOn": today,
      "policyNumber": this.policyNumber,
       "reqtype":'send'
    }
    this.ApiService.apirequest('/policy/cancellation', obj).subscribe(data => {
      let response = data.json();
      this.appComponent.loaderfunction(false);
      if (response.status) {
        $(".swipe-card").css({ "transform": "translate(0 ,1000px)", "transition": "5s linear" });
        $(".animation-circle-ripples").addClass("animate");
        $(".hidden-text-layer").css({ "opacity": "1", "transition": ".5s linear" });
        localStorage.setItem('event', 'surrender');
        this.home.getObject({ "updatedata" : obj , policyNumber :  this.policyNumber ,"reqtype":'verify', "updatetype":'suurender'});
        this.success(3000).then(() => { this.home.mobileModal(); this.home.setFlag('otp') });
        Analytics.record({ name: 'surrender_button', attributes: { mobile: localStorage.getItem('visit') }});
      }
      else {
        this.errormsg = response.message;
        this.erroropenAlert();
      }
    })
  }
  // card bottom event
  chagnedetected: boolean = false;
  checkEdge(event): void {
    this.edge = event;
    if (event.bottom == false) {
      this.chagnedetected = false;
      this.openAlert();
      $(".hide-move-div h5,.hide-when-slide").css({ "opacity": "0", "transition": ".5s linear" });
    }
    else {
      $(".hide-move-div h5, .hide-when-slide").css({ "opacity": "1", "transition": ".5s linear" });
      this.chagnedetected = true;
      this.closeAlert();
    }
  }
}
