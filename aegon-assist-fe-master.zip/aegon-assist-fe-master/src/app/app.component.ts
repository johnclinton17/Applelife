/*
 * aegonlife - v1.0.0 - 2019
 * @author aegonlife Insurance
 * app.component.ts
 * Description: router animation
 * Copyright (c) 2019 aegonlife Insurance
 */
import { Component, Renderer2, OnInit } from '@angular/core';
import { Router, NavigationStart } from '@angular/router';
import { ApiService } from './api/api.service';
import { ResponsiveService } from './responsive.service';
import { SwUpdate } from '@angular/service-worker';
import { MzToastService } from 'ngx-materialize';

declare var window: any;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  previousUrl: string = '';
  loader: boolean = false;
  inBounds: boolean = true;

 
  constructor(private renderer: Renderer2,private toastService: MzToastService, private router: Router, private ApiService: ApiService, private swUpdate: SwUpdate, private responsiveService: ResponsiveService) {
    this.router.events
      .subscribe((event) => {
        // loader on each page navigation
        if (event instanceof NavigationStart) {
          // router animation
          if (this.previousUrl) {
            localStorage.setItem('previousUrl', this.previousUrl);
            this.renderer.removeClass(document.body, this.previousUrl);
          }
          let currentUrlSlug = '';
          currentUrlSlug = event.url.slice(1)
          if (currentUrlSlug) {
            var str = currentUrlSlug.replace('/', '')
            if (this.previousUrl) {
              var prestr = this.previousUrl.replace('/', '')
              this.renderer.removeClass(document.body, prestr);
            }
            this.renderer.addClass(document.body, str);
          }
          this.previousUrl = currentUrlSlug;
        }
      });
  }
  ngOnInit() {
    if (this.swUpdate.isEnabled) {
      this.swUpdate.available.subscribe(() => {
        this.toastService.show('New version is available   <a href="" (click)="updateversion()"> Update Version </a>', 30000, 'black', () => { });
      });
    }
    
  }
  
  updateversion() {
    window.location.reload();
  }
  loaderfunction(action) {
    setTimeout(() => {
      this.loader = action;
    }, 100);
  }
  onResize() {
    this.responsiveService.checkWidth();
  }
  startLoader() {
    this.loader = true;
    this.ApiService.destroySuccess(2000).then(() => { this.loader = false; });
  }
}