/*
 * aegonlife - v1.0.0 - 2019
 * @author aegonlife Insurance
 * desktoplogin.component.ts
 * Description: desktop login for users
 * Copyright (c) 2019 aegonlife Insurance
 */
import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ApiService } from './../api/api.service';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { AegonauthService } from '../aegonauth.service';
import { BehaviorSubject } from 'rxjs';
import { environment } from '../../environments/environment';
import * as moment from 'moment';
import { AppComponent } from '../app.component';
import { ResponsiveService } from '../responsive.service';
import Analytics from '@aws-amplify/analytics';


@Component({
  selector: 'app-desktop-login',
  templateUrl: './desktop-login.component.html'
})

export class DesktopLoginComponent implements OnInit {
 
  // animated veriable declearation
  public lottieConfig: Object;
  public logininfo: any = { mobile_number: ''};
  private anim: any;
  public otpFlag: boolean;
  public otpformopen: boolean = false;
  public errorNumberFlag: boolean;
  public errorFlag: boolean = false;
  public otpstart: boolean = false;
  public errormsg: String;
  public loader: boolean = false;
  public user_name: string;
  errorMessage: string;
  private phones_ = new BehaviorSubject('');
  public phones = this.phones_.asObservable();
  userDetails: any;
  day: any;
  month: any;
  year: any;
  policyNumber: any;
  prolicyDetail: any;
  errorMsg: String
  otpText: string;
  loginWithText: any;
  successMessage: string; 
  successFlag = false;
  disablestatus : boolean = false;
  isMobile: boolean;
  copyRightYear : string;
  @ViewChild('mobile') mobile: ElementRef;
  constructor(private ApiService: ApiService, private responsiveService: ResponsiveService, private router: Router,  private auth: AegonauthService, public appload: AppComponent) {
    // animation configs
    this.lottieConfig = this.ApiService.animationConfig('assets/icons/animation-json/1708-success.json', true);

  }

  ngOnInit() {
    this.copyRightYear = moment().format('YYYY');
    if (this.ApiService.getaccessToken().accessToken) {
     // this.router.navigate(['/home']);
    }
    else {
      this.auth.signOut();
    }
    this.ApiService.destroySuccess(null).then(() => { this.errorFlag = false });
  }

  handleAnimation(anim: any) {
    this.anim = anim;
  }
  successAnimation() {
    this.anim.play();
  }
  intToHex(nr: number) {
    return nr.toString(16).padStart(2, '0');
  }
 
  // resize fucntion
  onResize(): void {
    this.responsiveService.getMobileStatus().subscribe(isMobile => {
      this.isMobile = isMobile;
    });
  }

  disclaimermodal() {
    // Get the modal
    var modal = document.getElementById("disclaimer-modal");
     document.body.className += ' ' + 'modal-open';
    $('#disclaimer-modal').removeClass('modalleave');
    modal.style.display = "block";
  }
  closeDisclaimerModal()  {
    document.querySelector('body').classList.remove('modal-open');
    var modal = document.getElementById("disclaimer-modal");
    if (this.isMobile) {
      $('#disclaimer-modal').addClass('modalleave');
      this.ApiService.destroySuccess(500).then(() => { $('#disclaimer-modal').removeClass('modalleave'); modal.style.display = "none"; });
    } else {
      modal.style.display = "none";
    }

  }
  
  public async userVerification(loginForm: NgForm) {
   

    if ((this.logininfo.mobile_number != '')) {
      this.appload.loaderfunction(true);
      if ((loginForm.valid && this.logininfo.mobile_number.length > 9)) {

        if (this.logininfo.mobile_number && this.logininfo.mobile_number != '') {
          this.user_name = environment.countryCode + this.logininfo.mobile_number;
          this.loginWithText = 'Mobile Number';
        }
        try {
          let visited = localStorage.getItem('visit');
          if (!visited || (visited && visited != this.logininfo.mobile_number)) {
            await this.auth.signUp(this.user_name);
          }
          await this.auth.signIn(this.user_name);
          this.appload.loaderfunction(false);
          this.otpformopen = true;
          this.otpmodal();
          Analytics.record({ name: 'login_OTP', attributes: { mobile: this.logininfo.mobile_number}});
          await this.auth.getPublicChallengeParameters().then(param => this.phones_.next(param.phone_number));;
        }
        catch (err) {
          if (err.code == "UsernameExistsException") {
            try {
            await this.auth.signIn(this.user_name);
            this.otpformopen = true;
            this.otpmodal();
            await this.auth.getPublicChallengeParameters().then(param => this.phones_.next(param.phone_number));
            }
            catch(err)
            {
              var msg =  err.message.replace("CreateAuthChallenge failed with error ", "")
              this.errormsg = msg;
              this.errorFlag = true;
            }
          }
          else {
            this.errormsg = err.message.replace("CreateAuthChallenge failed with error ", "");
            this.errorFlag = true;
          }
          this.appload.loaderfunction(false);
        }
      }
      else {
        this.appload.loaderfunction(false);
        this.errormsg = 'Please enter a valid mobile number'; 
        if (loginForm.form && loginForm.form.controls.mobile_number.invalid) { this.errormsg = 'Please enter a valid mobile number'; }
        this.errorFlag = true;
      }
      this.ApiService.destroySuccess(null).then(() => { this.errorFlag = false; });
    }
    else {
      this.errormsg = 'Please enter a mobile number';
      this.errorFlag = true;
      this.ApiService.destroySuccess(null).then(() => { this.errorFlag = false; });
      this.appload.loaderfunction(false);
      this.mobile.nativeElement.focus()
    }
  }
  otpmodal() {
    // Get the modal
    var modal = document.getElementById("otp-modal");
    modal.style.display = "block";
  }
  closeOtpModal() {
    var modal = document.getElementById("otp-modal");
    modal.style.display = "none";
    this.errorFlag = false;
    this.otpText = '';
  }
  async otpAction(event) {
    
    var otp = this.otpText;
    if (otp.length == 6 && !this.otpstart) {
      $('input').blur();
      this.disablestatus = true;
      this.otpstart = true;
      this.otpstart = false;
      this.appload.loaderfunction(true);
      try {
        const loginSucceeded = await this.auth.answerCustomChallenge(otp);
        if (loginSucceeded) {
          this.appload.loaderfunction(false);
          this.otpFlag = true;
          localStorage.setItem('visit', this.logininfo.mobile_number);
            this.ApiService.destroySuccess(null).then(() => { this.anim.stop(); });
            this.ApiService.getRequest('/policies').subscribe(data => {
              var response = data.json();
               if (response.status) { 
                   this.router.navigate(['/home']);
                 Analytics.record({ name: 'Successful Login', attributes: { mobile: this.logininfo.mobile_number} });
               }
               else
               {
                this.ApiService.destroySuccess(2000).then(() => { 
                 this.closeOtpModal();
                 this.logininfo = { mobile_number: ''};
                this.errormsg = response.message; 
                this.errorFlag = true;
                  Analytics.record({ name: 'Failed Login', attributes: { mobile: this.logininfo.mobile_number } });
                });
               }
              
            });
           
        }
        else {
          this.errorMessage = "Invalid OTP. Please try again.";
          Analytics.record({ name: 'Failed Login', attributes: { mobile: this.logininfo.mobile_number } });
          this.errorFlag = true;
          this.disablestatus = false;
          this.otpText = '';
          await this.auth.getPublicChallengeParameters().then(param => this.phones_.next(param.phone_number));
          this.ApiService.destroySuccess(null).then(() => { this.errorFlag = false });
          this.appload.loaderfunction(false);
        }
        
      }
      catch (err) {
        await this.auth.getPublicChallengeParameters().then(param => this.phones_.next(param.phone_number));
        this.errorMessage = "Error! Please try again.";
        this.errorFlag = true;
        this.otpText = '';
        this.ApiService.destroySuccess(null).then(() => { this.errorFlag = false });
        this.appload.loaderfunction(false);
      }
    }
  }
  count = 0;
  public async resentotp() {
    
      try {
        await this.auth.signIn(this.user_name);
        await this.auth.getPublicChallengeParameters().then(param => this.phones_.next(param.phone_number));
        this.successMessage = "OTP has been resent";
        Analytics.record({ name: 'login_otp_resent', attributes: { mobile: this.logininfo.mobile_number }});
        this.successFlag = true;
        this.destroyError(9000).then(() => { this.successFlag = false; });
      }
      catch (err) {
        var msg =  err.message.replace("CreateAuthChallenge failed with error ", "")
        this.errorMessage = msg;
        this.errorFlag = true;
        this.destroyError(9000).then(() => { this.errorFlag = false; });
      }
  }
 
  // To get delay for user experience
  destroyError(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
  // only number will accepet
  onlyNumber(event): boolean {
    return this.ApiService.onlyNumber(event);
  }
}
