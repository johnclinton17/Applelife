/*
 * aegonlife - v1.0.0 - 2019
 * @author aegonlife Insurance
 * desktophome.component.ts
 * Description: user policy details and user details will display 
 * Copyright (c) 2019 aegonlife Insurance
 */

import { Component, OnInit, ViewChild } from '@angular/core';
import { ApiService } from './../api/api.service';
import { Router } from '@angular/router';
import { NgNavigatorShareService } from 'ng-navigator-share';
import { ResponsiveService } from '../responsive.service';
import { AppComponent } from '../app.component';
import * as moment from 'moment';
import Analytics from '@aws-amplify/analytics';
import { DomSanitizer, SafeResourceUrl, } from '@angular/platform-browser';
let routesObject = require('../../assets/scheme-config.json');

declare var $: any;


@Component({
  selector: 'app-desktophome',
  templateUrl: './desktophome.component.html'
})
export class DesktophomeComponent implements OnInit {
  // animated veriable declearation
  public lottieConfig: Object;
  public otplottieConfig: Object;
  public emaillottieConfig: Object;
  userDetails: any;
  firstName: string;
  lastName: string;
  name: string;
  policyDetail = <any>{};
  policyName: string;
  policies = [];
  policynum: string;
  sumAssured: any;
  dateOfBirth: any;
  mobileNumber: any;
  viewpolicy = false;
  policyStatus: any;
  deviceInfo: any;
  clientName: string;
  requestId: string;
  // set flag for show n hide 
  showMobileFlag = false;
  showEmailFlag = false;
  showNomineeFlag = false;
  showSurrenderFlag = false;
  showOtpFlag = false;
  showFeedbackFlag = false;
  trackFlag = false;
  allowuser: boolean = false;
  title: string;
  isMobile: boolean;
  documentDownload;
  copyRightYear: string;
  errormsg:boolean;
  schemeData = [] ;
  videoUrl : any;
  difference : any;
  @ViewChild('player')
  urlSafe: SafeResourceUrl;
  private ngNavigatorShareService: NgNavigatorShareService;
  slideConfig = {
    "slidesToShow": 1, 'dots': true, 'arrows': false, "slidesToScroll": 1, 'centerMode': false, 'infinite': false
  };
  activePolicy: any;
  constructor(public sanitizer: DomSanitizer,public appComponent: AppComponent, private responsiveService: ResponsiveService, private ApiService: ApiService, private router: Router, ngNavigatorShareService: NgNavigatorShareService) {
    this.ngNavigatorShareService = ngNavigatorShareService;
  }
  // mobile modal trigger
  mobileModal(): void {
    this.appComponent.startLoader();
    // to start loader
    document.body.className += ' ' + 'modal-open';
    // Get the modal
    var modal = document.getElementById("mobile-modal");
    $('#mobile-modal').removeClass('modalleave');
    modal.style.display = "block";
  }
  closeMobileModal(type): void {
    this.showMobileFlag = this.showEmailFlag = this.showNomineeFlag = this.showSurrenderFlag = this.showOtpFlag = false;
    this.showFeedbackFlag = this.trackFlag = false;
    document.querySelector('body').classList.remove('modal-open');
    var modal = document.getElementById("mobile-modal");
    if (this.isMobile) {
      $('#mobile-modal').addClass('modalleave');
      this.ApiService.destroySuccess(500).then(() => { $('#mobile-modal').removeClass('modalleave'); modal.style.display = "none"; });
    } else {
      modal.style.display = "none";
    }
    if (type == 'reload') {
      this.ngOnInit();
    }
  }
  videoModal(): void {
    document.body.className += ' ' + 'modal-open';
    var modal = document.getElementById("watch-modal");
    modal.style.display = "block";
    $('#watch-modal').removeClass('modalleave');
    Analytics.record({ name: 'Watch Video', attributes: { mobile: localStorage.getItem('visit')} });
  }
  closevideoModal(): void {
    document.querySelector('body').classList.remove('modal-open');
    var modal = document.getElementById("watch-modal");
    $("#watch-modal iframe").attr("src", $("#watch-modal iframe").attr("src"));
    if (this.isMobile) {
      $('#watch-modal').addClass('modalleave');
      this.ApiService.destroySuccess(500).then(() => { $('#watch-modal').removeClass('modalleave'); modal.style.display = "none"; });
    } else {
      modal.style.display = "none";
    }
  }
  
  faqModal(): void {
    document.body.className += ' ' + 'modal-open';
    var modal = document.getElementById("faq-modal");
    modal.style.display = "block";
    $('#faq-modal').removeClass('modalleave');
    Analytics.record({ name: 'FAQs', attributes: { mobile: localStorage.getItem('visit') } });
  }
  closeFaqModal(): void {
    document.querySelector('body').classList.remove('modal-open');
    var modal = document.getElementById("faq-modal");
    if (this.isMobile) {
      $('#faq-modal').addClass('modalleave');
      this.ApiService.destroySuccess(500).then(() => { $('#faq-modal').removeClass('modalleave'); modal.style.display = "none"; });
    } else {
      modal.style.display = "none";
    }
  }
  brochureDownload(){
    Analytics.record({ name: 'Download Product Brochure', attributes: { mobile: localStorage.getItem('visit') } });
  }
  
  closetimeAlert(): void {
    let errormodal = document.getElementById("timoutmodel");
    document.querySelector('body').classList.remove('modal-open');
    errormodal.style.display = "none";
    this.ApiService.resettimer();
  }
  logoutAlert()
  {
    this.ApiService.storageclean();
    this.router.navigate(['/login']);
  }

  doclinkModal(): void {
    this.appComponent.startLoader()
    document.body.className += ' ' + 'modal-open';
    // Get the modal
    this.getDocument('copy','getdoc');
    var modal = document.getElementById("doc-url");
    modal.style.display = "block";
  }
  closedoclinkModal(): void {
    document.querySelector('body').classList.remove('modal-open');
    var modal = document.getElementById("doc-url");
    modal.style.display = "none";
  }
  //copy doc link
  copyLink(element) {
    element.select();
    document.execCommand("copy");
  }
  //  check for only numbers
  onlyNumber(event): boolean {
    return this.ApiService.onlyNumber(event);
  }
  userdata() {
    return this.userDetails;
  }
  policydata() {
    this.ApiService.resettimer();
    return this.activePolicy;
  }
  setrequestId(requestId) {
    this.requestId = requestId;
  }
  getrequestId() {
    return this.requestId;
  }
  allpoldata = [];
  userinfo = [];
  ngOnInit() {
    this.copyRightYear = moment().format('YYYY');
    this.appComponent.loaderfunction(true);
    this.userDetails = {};
    this.ApiService.startTimer(); 
    // resize event
    this.onResize();
    this.policies = [];
    this.userinfo=[];
    this.ApiService.getRequest('/policies').subscribe(data => {
      var response = data.json();
      if (!response.status) {
        //this.ApiService.storageclean();
        //this.router.navigate(['/login']);

      } else {
        var copy = Object.assign([], response.data);
        this.allpoldata = copy;
        this.getpolicy(response.data[0], 0, response.data, "init");
      }
    }, err => {
      this.router.navigate(['/login']);
      this.appComponent.loaderfunction(false)
    })
  
  }
  getpolicy(policyNumber, index, policyresponse, type) {
    this.schemeData = [];  
    this.ApiService.getRequest('/policy/policyNumber/' + policyNumber).subscribe(data => {
      var response = data.json();
      if (response.status) {
        this.policyDetail = response.policyinfo;
        if (index == 0 && type == 'init') {
        this.policies = policyresponse;
        }
        this.policies[index] = this.policyDetail;
        this.activePolicy = this.policyDetail;
        this.setallowedtype(this.policyDetail);
        this.userDetails = response.partinfo;
        this.userinfo[index] = response.partinfo;
        this.activePolicy = this.policyDetail;
       
        this.setValueCard(this.userDetails,this.policyDetail);
        if (this.policies.length == 1) {
          this.slideConfig.dots = false;
        }
        else {
          this.slideConfig.dots = true;
        }
        this.checkSurrender(this.activePolicy);
        this.appComponent.loaderfunction(false);

      }
      else {
        this.errormsg = response.message;
       this.erroropenAlert();
        this.appComponent.loaderfunction(false);
      }
    })
  }
// set value in variable for card new

setValueCard(userDetails,policyDetail){
  this.getDocument('share','onload');
  this.userDetails = userDetails;
  this.firstName = userDetails.firstName;
  this.lastName = userDetails.lastName || '';
  this.name = userDetails.firstName + ' ' + userDetails.lastName;
  //console.log(policyDetail.product.planCode);
  if (routesObject[policyDetail.product.schemeCode]){
    this.schemeData=routesObject[policyDetail.product.schemeCode];
    var objectName = policyDetail.product.schemeCode+'video'
    if(routesObject[objectName]){
      this.videoUrl = this.sanitizer.bypassSecurityTrustResourceUrl(routesObject[objectName].video);
    }else{
      this.videoUrl = this.sanitizer.bypassSecurityTrustResourceUrl('');
    }
  }
  else{
    this.schemeData = [];
    this.videoUrl = this.sanitizer.bypassSecurityTrustResourceUrl('');
  }
}

  setallowedtype(policyDetail)
  {
 this.allowuser = (policyDetail.policyStatus && (policyDetail.policyStatus.status=='TERMINATED' || policyDetail.policyStatus.status=='LAPSED'))?true:false;
  }

  erroropenAlert(): void {
    document.body.className += ' ' + 'modal-open';
    let errormodal = document.getElementById("errormodel");
    errormodal.style.display = "block";
  }
  errorcloseAlert(): void {
    let errormodal = document.getElementById("errormodel");
    document.querySelector('body').classList.remove('modal-open');
    errormodal.style.display = "none";
    this.ApiService.storageclean();
    this.router.navigate(['/login']);

  }
  identify(index, item) {
    return index;
  }
  activatecard(event) {
    this.appComponent.loaderfunction(true);
  }

  changepolicy(event) {
    var cpolicy = this.allpoldata[event.currentSlide];
    var existpolicy = this.policies[event.currentSlide];
    var existuser = this.userinfo[event.currentSlide];
    if (!existpolicy.policyNumber) {
      this.getpolicy(cpolicy, event.currentSlide, '', 'load');
    }
    else {
      this.setValueCard(existuser,existpolicy)
      this.activePolicy = existpolicy;
      this.setallowedtype(existpolicy);
      this.appComponent.loaderfunction(false);
      this.checkSurrender(this.activePolicy);
    }
  }


   checkSurrender(activePolicy){
    let before = moment(activePolicy.issueDate);
    let now = moment();
    this.difference = now.diff(before, 'days');
    let freelookPeriod = activePolicy.freelookPeriod;
    if(((this.activePolicy.policyStatus.status!='TERMINATED' && this.activePolicy.policyStatus.status!='LAPSED') && parseInt(freelookPeriod) >= parseInt(this.difference))  ||((this.activePolicy.policyStatus.status!='TERMINATED' && this.activePolicy.policyStatus.status!='LAPSED') && parseInt(freelookPeriod) >= parseInt(this.difference)) )
      {
        $('#cancellnk').show();
      }
      else
      {
      
        $('#cancellnk').hide(); 
      }

  }
  // resize fucntion
  onResize(): void {
    this.responsiveService.getMobileStatus().subscribe(isMobile => {
      this.isMobile = isMobile;
    });
  }
  getDocument(type,typeofload) {
    // documentInfo
   
    if (this.activePolicy.documents[0].id && this.activePolicy.documents[0].id != '') {
      this.ApiService.getRequest('/documentInfo/' + this.activePolicy.documents[0].id).subscribe(data => {
        var response = data.json();
        if (!response.message) {
            this.documentDownload = '';
          this.documentDownload = response.signedUrl;
          if (type == 'download') {
            this.downloadMyFile();
           
            Analytics.record({
              name: 'view_policy_download', attributes: {mobile: localStorage.getItem('visit')}});
          }
          else {
            //this.sharePolicy(this.documentDownload);
          }
        }
        else {
          if(typeofload!='onload')
          {
          this.viewpolicy = true;
          }
          this.ApiService.destroySuccess(5000).then(() => { this.viewpolicy = false; });
        }
      })
    } else {
      if(typeofload!='onload')
      {
      this.viewpolicy = true;
      }
      this.ApiService.destroySuccess(5000).then(() => { this.viewpolicy = false; });
    }
  }
  downloadMyFile() {
    if (this.documentDownload != '' && this.documentDownload) {
      const link = document.createElement('a');
      link.setAttribute('href', this.documentDownload);
      link.setAttribute('download', 'policy.pdf');
      document.body.appendChild(link);
      link.click();
      link.remove();
    }
    else {
      this.viewpolicy = true;
      this.ApiService.destroySuccess(5000).then(() => { this.viewpolicy = false; });
    }
  }
  // share the view policy doc
  async sharePolicy() {
    this.getDocument('share','getdoc')
    try {
      const sharedResponse = await this.ngNavigatorShareService.share({
        title: 'Policy Document',
        text: 'Policy Document',
        url: this.documentDownload
      });
      Analytics.record({ name: 'share_button', attributes: { mobile: localStorage.getItem('visit') } });
    } catch (error) {

      // this.viewpolicy = true;
      // this.ApiService.destroySuccess(5000).then(() => {  this.viewpolicy = false; });
    }
  }
  // clear the localStroage 
  clearstorage(): void {
    localStorage.setItem('addnominee', 'false')
  }

  setAction(action){
    Analytics.record({ name: action, attributes: { mobile: localStorage.getItem('visit') } });
  }

  setFlag(type) {

    this.showMobileFlag = this.showEmailFlag = this.showNomineeFlag = this.showSurrenderFlag = this.showOtpFlag = false;
    this.showFeedbackFlag = this.trackFlag = false;
    if (type == 'mobile') {
      this.showMobileFlag = true;
      this.title = "Update Mobile Number";
      this.setAction(this.title);
      this.storeAction('mobile')
    }
    if (type == 'email') {

      this.showEmailFlag = true;
      this.title = "Update Email Address";
      this.setAction(this.title);
      this.storeAction('email')
    }
    if (type == 'nominee') {
      this.showNomineeFlag = true;
      this.title = "Update Nominee"
      this.setAction(this.title);
      this.storeAction('nominee')
    }
    if (type == 'surrender') {
      this.showSurrenderFlag = true;
      this.title = "Cancel Policy";
      let wrapperElement1 = document.getElementsByClassName('inner-wrapper') as HTMLCollectionOf<HTMLElement>;
      wrapperElement1[0].classList.add('surrender-wrapper');
      this.setAction(this.title);
      this.storeAction('surrender')
    }
    if (type == 'otp') {
      this.showOtpFlag = true;
      this.title = "OTP";
      this.setAction(this.title);
    }
    if (type == 'feedback') {
      this.showFeedbackFlag = true;
      this.title = "Feedback";
      this.setAction(this.title);
    }
    if (type == 'track') {
      this.trackFlag = true;
      this.title = "Track Request";
      this.setAction(this.title);
    }

  }
  // to set the update object for mobile , email , Nominee
  updateContacObj: any;
  getObject(object) {
    this.updateContacObj = object;
  }
  setObject() {
    return this.updateContacObj;
  }
// set action

storeAction(action){
  localStorage.setItem('action',action)
}

}
