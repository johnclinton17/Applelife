import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmailupdateComponent } from './emailupdate.component';

describe('EmailupdateComponent', () => {
  let component: EmailupdateComponent;
  let fixture: ComponentFixture<EmailupdateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmailupdateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmailupdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // it('should create', () => {
  //  expect(component).toBeTruthy();
  // });
});
