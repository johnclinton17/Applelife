import { Component, OnInit } from '@angular/core';
import { ApiService } from './../api/api.service';
import { DesktophomeComponent } from '../desktophome/desktophome.component';
import { AppComponent } from '../app.component';
import Analytics from '@aws-amplify/analytics';
@Component({
  selector: 'app-emailupdate',
  templateUrl: './emailupdate.component.html'
})
export class EmailupdateComponent implements OnInit {

  constructor(private ApiService: ApiService,public home:DesktophomeComponent,private appComponent : AppComponent) { }
  userDetails: any;
  mobileNo : string;
  emailId : string;
  email_id: string;
  updatetype : string;
  errorNumberFlag = false;
  policyDetails : any;
  errorMsg: string;
  updateObj = {
    "email": '',
    "policyNumber": ''
  };
  ngOnInit() {
    this.email_id ='';
    this.userDetails = this.home.userdata();
    this.policyDetails = this.home.policydata();
    this.updateObj.policyNumber = this.policyDetails.policyNumber;
   // get user deatail
    this.emailId =  this.userDetails.email;
    this.mobileNo =  this.userDetails.mobile;
    // get user deatail

  }
  

  // to send otp on mobile and email
  updateProfile(type) {
    this.updatetype = type;
    this.appComponent.loaderfunction(true);
   if (type == 'email' ) {
       this.updateRequest('send', type);
       this.updateObj.email = this.email_id;
     }
     else {
      this.appComponent.loaderfunction(false);
       this.errorNumberFlag = true;
       this.errorMsg = "Your email address is invalid.";
       this.ApiService.destroySuccess(3000).then(() => { this.errorNumberFlag = false; });
     }
 }
  // to send otp mobile email
 updateRequest(reqtype, updatetype) {
  this.ApiService.apirequest('/endorsements/contacts', {  reqtype: reqtype, updatetype: updatetype,updatedata : this.email_id , policyNumber : this.updateObj.policyNumber }).subscribe(data => {
    let response = data.json();
    if (response.status) {
      this.home.setFlag('otp')
      localStorage.setItem('event','contact');
      Analytics.record({ name: 'email update', attributes: { mobile: this.mobileNo } });
      this.home.getObject({ "updatedata" : this.updateObj ,email : this.email_id, policyNumber : this.updateObj.policyNumber , "reqtype":'verify', "updatetype":'email', "otp": '' });
    }
    else {
      this.errorNumberFlag = true;
      this.errorMsg = response.message;
      this.ApiService.destroySuccess(3000).then(() => { this.errorNumberFlag = false; });
    }
    this.appComponent.loaderfunction(false);
  }, err => {
    this.errorNumberFlag = true;
    this.errorMsg =  "Session Timeout Please sign in again.";
    this.ApiService.destroySuccess(3000).then(() => { this.errorNumberFlag = false; });
    this.appComponent.loaderfunction(false);
  })
}

}
