import { TestBed } from '@angular/core/testing';
import { HttpModule,Http } from '@angular/http';
import { DeviceDetectorService } from 'ngx-device-detector';
import { ApiService } from './api.service';

describe('ApiService', () => {
  beforeEach(() => TestBed.configureTestingModule({
  	providers: [ApiService,DeviceDetectorService],
  	 imports: [HttpModule]
  }));

  it('should be created', () => {
    const service: ApiService = TestBed.get(ApiService);
    expect(service).toBeTruthy();
  });
});
