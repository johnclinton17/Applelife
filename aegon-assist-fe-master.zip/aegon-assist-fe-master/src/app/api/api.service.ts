/*
 * aegonlife - v1.0.0 - 2019
 * @author aegonlife Insurance
 * service.ts
 * Description: All HTTP methods like GET, POST, PUT and DELETE APIs to retrieve data and update/insert/delete data.
 * Copyright (c) 2019 aegonlife Insurance
 */
//import all dependency file for initiate service
import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions } from '@angular/http';
import { Observable, Subject,BehaviorSubject } from 'rxjs';
import { map } from 'rxjs/operators';
import * as CryptoJS from 'crypto-js';
import { environment } from '../../environments/environment';
import { DeviceDetectorService } from 'ngx-device-detector';
import { AegonauthService } from '../aegonauth.service';
import { UserIdleService } from 'angular-user-idle';
import { startTimeRange } from '@angular/core/src/profile/wtf_impl';

let routesObject = require('../../assets/config.json');
declare var require: any

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  deviceInfo: any;
  private _unsubscribeAll: Subject<any>;
  constructor(private deviceService: DeviceDetectorService, private userIdle: UserIdleService, private _http: Http, private auth: AegonauthService, ) {  // Set the private defaults
    this._unsubscribeAll = new Subject();
    this.epicFunction();
  }
  // get the device info
  epicFunction(): void {
    this.deviceInfo = this.deviceService.getDeviceInfo();
  }
  // url to connect with the node server
  public apiUrl = environment.api_url // node server
  //post api servcies
  startTimer()
  {
    this.userIdle.startWatching();
    this.userIdle.onTimerStart().subscribe(count => (count == 5) ? this.erroropenAlert() : '');
    this.userIdle.onTimeout().subscribe(() =>  this.storageclean());
  }
  resettimer()
  {
    this.userIdle.resetTimer();  
  }

  erroropenAlert(): void {
    document.body.className += ' ' + 'modal-open';
    let errormodal = document.getElementById("timoutmodel");
    errormodal.style.display = "block";
  }
  apirequest(url, params) {
    // set Expiry time for JWT token
    this.resettimer();
    this.expiredate();
    let headers = new Headers({
      'Content-Type': 'application/json',
      'Authorization': this.getaccessToken().idtoken,
      "x-api-key": environment.apiKey
    });
    this.deviceInfo = this.deviceService.getDeviceInfo();
    var apidata = params;
    apidata.deviceInfo = this.deviceInfo;
    var data = this.encryptdata(JSON.stringify(apidata));
    let options = new RequestOptions({ headers: headers });
    return this._http.post(this.apiUrl + "" + url, {data:data}, options).pipe(map(res => res));
  }
  // get api services
  getRequest(url): Observable<any> {
    this.expiredate();
    this.resettimer();
    let headers = new Headers({
      'Content-Type': 'application/json',
      'Authorization': this.getaccessToken().idtoken,
      "x-api-key": environment.apiKey
    });
    let options = new RequestOptions({ headers: headers });
    return this._http.get(this.apiUrl + url, options).pipe(map(res => res));
  }
  expiredate()
  {
    var expirationMS = 350 * 60 * 1000;
    var record = { timestamp: new Date().getTime() + expirationMS }
    localStorage.setItem('expirecheck', JSON.stringify(record));
  }
  // encryp and decrypt service methods
  encryptdata(value) {
    var key = environment.encrypt_key;
    var encrypted = CryptoJS.AES.encrypt(value, key);
    return encrypted.toString();
  }
  //The get method is use for decrypt the value.
  // promise to get some delay 
  destroySuccess(ms) {
    var wait = 3000;
    if (ms) { wait = ms };

    return new Promise(resolve => setTimeout(resolve, wait));
  }
  storageclean() {
    this.auth.signOut();
    localStorage.removeItem('accessToken');
    localStorage.removeItem('secretToken');
    localStorage.removeItem('expirecheck');
    localStorage.removeItem('partyid');
    localStorage.removeItem('message');
    localStorage.removeItem('policynum');
  }
  //  animation config
  animationConfig(path, autoplay) {
    var lottieConfig = {
      path: path,
      renderer: 'canvas',
      autoplay: autoplay,
      loop: false
    };
    return lottieConfig;
  }
  // onlynumber on keybaord press 
  onlyNumber(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
  // get token to access api's
  getaccessToken() {
    if (localStorage.getItem('accessToken')) {
      let tokenObj = {
        "token": '',
        "accessToken": localStorage.getItem('accessToken'),
        "idtoken": localStorage.getItem('secretToken'),
      }
      return tokenObj;
    } else {
      let tokenObj = {
        "token": '',
        "accessToken": '',
        "idtoken": ''
      }
      return tokenObj;
    }
  }
  ngOnDestroy(): void {
    // Unsubscribe from all subscriptions
    this._unsubscribeAll.next();
    this._unsubscribeAll.complete();
  }
  dateFormat() {
    var currenDate = new Date();
    let dobYear = currenDate.getFullYear() - 18;
    return '01-01' + '-' + dobYear

  }
  title = new BehaviorSubject('');
  setTitle(title: string) {
    this.title.next(title);
  }
  getDeviceInfo() {
    return this.deviceInfo
  }

  firstName: string = 'Stephen';
  validateEmail(emailField) {
    var reEmail = /^(?:[\w\!\#\$\%\&\'\*\+\-\/\=\?\^\`\{\|\}\~]+\.)*[\w\!\#\$\%\&\'\*\+\-\/\=\?\^\`\{\|\}\~]+@(?:(?:(?:[a-zA-Z0-9](?:[a-zA-Z0-9\-](?!\.)){0,61}[a-zA-Z0-9]?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9\-](?!$)){0,61}[a-zA-Z0-9]?)|(?:\[(?:(?:[01]?\d{1,2}|2[0-4]\d|25[0-5])\.){3}(?:[01]?\d{1,2}|2[0-4]\d|25[0-5])\]))$/;
    if (!emailField.match(reEmail)) {
      return false;
    }
    return true;
  }
}
