/*
 * aegonlife - v1.0.0 - 2019
 * @author aeonlife Insurance
 * feedback.component.ts
 * Description: get Feedbacks from users
 * Copyright (c) 2019 aegonlife Insurance
 */
import { Component, OnInit } from '@angular/core';
import { ApiService } from './../api/api.service';
import { DeviceDetectorService } from 'ngx-device-detector';
import { DesktophomeComponent } from '../desktophome/desktophome.component';
import Analytics from '@aws-amplify/analytics';

@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html'
})
export class FeedbackComponent implements OnInit {
  public lottieConfig: Object;
  private anim: any;
  elementSad: any ;
  elementOkay : any;
  elementLove : any;
  message: string;
  ratings: string;
  requestId: string;
  deviceInfo : any  ;
  clientName: string;
  policyNumber: string;
  mobileNumber: any;

  feedEle:any;
  event : string;
  policyDetails;
  constructor(private deviceService: DeviceDetectorService,public home:DesktophomeComponent, private ApiService: ApiService ) {
    this.lottieConfig = {
      path: 'assets/icons/animation-json/1708-success.json',
      renderer: 'canvas',
      autoplay: false,
      loop: false
    };
    this.epicFunction();
  }
  handleAnimation(anim: any): void {
    this.anim = anim;
  }
  // get the device info
  epicFunction(): void {
    this.deviceInfo = this.deviceService.getDeviceInfo();
  }
  ngOnInit() {
    // feedbackSubmit
    (<HTMLInputElement> document.getElementById("feedbackSubmit")).disabled = true;

    this.message = '';
    this.event = '';
    this.policyDetails = this.home.policydata();
    this.policyNumber = this.policyDetails.policyNumber;
    this.requestId = this.home.getrequestId();
    this.elementSad = document.getElementById("sad");
    this.elementOkay = document.getElementById("okay");
    this.elementLove = document.getElementById("love");
     this.feedEle=document.getElementById('feedHide');
    // page url
    if(localStorage.getItem('event')){
      this.event = localStorage.getItem('event');
    }
   
  }

  switchSad(param): void {
    (<HTMLInputElement> document.getElementById("feedbackSubmit")).disabled = false;
    this.ratings = param;
    this.elementSad.classList.add("draw");
    this.elementOkay.classList.remove("draw");
    this.elementLove.classList.remove("draw");
  }
  switchOkay(param): void {
    (<HTMLInputElement> document.getElementById("feedbackSubmit")).disabled = false;
    this.ratings = param;
    this.elementSad.classList.remove("draw");
    this.elementOkay.classList.add("draw");
    this.elementLove.classList.remove("draw");
  }
  switchLove(param): void {
    (<HTMLInputElement> document.getElementById("feedbackSubmit")).disabled = false;
    this.ratings = param;
    this.elementSad.classList.remove("draw");
    this.elementOkay.classList.remove("draw");
    this.elementLove.classList.add("draw");
  }
  dealyPromise(ms) {
    return new Promise(resolve => setTimeout(resolve, ms))
  }
  
  // feedback
  submitFeedback() {
    let event_name = localStorage.getItem('action')
    this.feedEle.style.display = 'none';
    let wrapperElement2 = document.getElementsByClassName('wrapper2') as HTMLCollectionOf<HTMLElement>;
    wrapperElement2[0].style.opacity = '1';
    this.anim.play();
    var obj = {'ratings': this.ratings, "message": this.message, screen_name: this.event, policy_number: this.policyNumber, device_type: this.deviceInfo.device, os_type: this.deviceInfo.os, ip_address: '', browser: this.deviceInfo.browser, os_version: this.deviceInfo.os_version, browser_version: this.deviceInfo.browser_version };
    this.ApiService.apirequest('/feedback', obj).subscribe(data => {
      if(data)
      {
      var response = data.json();
      if (response.message == 'inserted') {
        this.dealyPromise(3000).then(() => { this.home.closeMobileModal('reload') })
        Analytics.record({ name: event_name + '_feedback_success', attributes: { mobile: localStorage.getItem('visit') } });
      }
      else {
        this.dealyPromise(3000).then(() => { this.home.closeMobileModal('reload') })
        Analytics.record({ name: event_name + '_feedback_failed', attributes: { mobile: localStorage.getItem('visit') } });
      }
    }
    else
    {
      this.dealyPromise(3000).then(() => { this.home.closeMobileModal('reload') })   
    }
    })
  }
}
