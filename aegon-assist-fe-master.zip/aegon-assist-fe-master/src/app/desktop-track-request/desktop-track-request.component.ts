import { Component, OnInit } from '@angular/core';
import { ApiService } from './../api/api.service';
import { DesktophomeComponent } from '../desktophome/desktophome.component';

@Component({
  selector: 'app-desktop-track-request',
  templateUrl: './desktop-track-request.component.html'
})
export class DesktopTrackRequestComponent implements OnInit {

  constructor(private ApiService: ApiService, public home: DesktophomeComponent) { }
  errorFlag = false;
  policyNumber: any;
  policyName: any;
  serviceRequestList = [];
  policyDetails: any;
  serviceRequests: any;
  errormsg: string;
  dataload: boolean = false;
  ngOnInit() {
    this.policyDetails = this.home.policydata();
    this.policyNumber = this.policyDetails.policyNumber;
    this.policyName = this.policyDetails.product.name;
    this.getServiceRequest();
  }
  getServiceRequest() {
    this.ApiService.getRequest('/servicerequests/' + this.policyNumber).subscribe(data => {
      this.serviceRequests = data.json();
      this.dataload = true;
      if (this.serviceRequests.status) {
        this.serviceRequestList = this.serviceRequests.data;
      }
      else {
        this.errorFlag = true;
        this.errormsg = this.serviceRequests.message;
      }
    })
  }
}
