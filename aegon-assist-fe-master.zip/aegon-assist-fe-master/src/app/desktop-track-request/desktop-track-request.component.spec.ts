import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MzNavbarModule, MzToastModule, MzSidenavModule, MzButtonModule, MzDropdownModule, MzCardModule, MzBadgeModule, MzCheckboxModule, MzTextareaModule, MzSelectModule, MzDatepickerModule, MzCollapsibleModule, MzModalModule } from 'ngx-materialize';

import { DesktopTrackRequestComponent } from './desktop-track-request.component';
import { AngularDraggableModule } from 'angular2-draggable';
import { DeviceDetectorService } from 'ngx-device-detector';
import { ApiService } from '../api/api.service';
import { FormsModule } from '@angular/forms';
import { HttpModule, Http } from '@angular/http';
import { RouterTestingModule } from '@angular/router/testing';

describe('DesktopTrackRequestComponent', () => {
  let component: DesktopTrackRequestComponent;
  let fixture: ComponentFixture<DesktopTrackRequestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        HttpModule,
        MzNavbarModule,
        MzSidenavModule,
        MzButtonModule,
        MzTextareaModule,
        MzDropdownModule,
        MzCardModule,
        MzCollapsibleModule,
        MzCheckboxModule,
        MzDatepickerModule,
        MzSelectModule,
        MzModalModule,
        MzBadgeModule, MzToastModule,
        AngularDraggableModule,
        RouterTestingModule,
      ],

      declarations: [ DesktopTrackRequestComponent ],
      providers: [DeviceDetectorService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DesktopTrackRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
