/*
 * aegonlife - v1.0.0 - 2019
 * @author aegonlife Insurance
 * otp.component.ts
 * Description: import all modules and routing 
 * Copyright (c) 2019 aegonlife Insurance
 */

//import all dependency file for building app
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MzNavbarModule,MzToastModule,  MzSidenavModule, MzButtonModule, MzDropdownModule, MzCardModule, MzBadgeModule, MzCheckboxModule, MzTextareaModule, MzSelectModule, MzDatepickerModule, MzCollapsibleModule } from 'ngx-materialize';
import { FormsModule ,ReactiveFormsModule} from '@angular/forms';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { Router, RouterModule } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { OtpComponent } from './otp/otp.component';
import { ApiService } from './api/api.service';
import { LottieAnimationViewModule } from 'ng-lottie';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';
import { MzModalModule } from 'ngx-materialize';
import { SlickCarouselModule } from 'ngx-slick-carousel';
import { UpdateProfileComponent } from './update-profile/update-profile.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { SurrenderPolicyComponent } from './surrender-policy/surrender-policy.component';
import { NomineeComponent } from './nominee/nominee.component';
import { AngularDraggableModule } from 'angular2-draggable';
import { AuthGuard } from './auth.guard';
import { DesktopLoginComponent } from './desktop-login/desktop-login.component';
import { DesktophomeComponent } from './desktophome/desktophome.component';
import { APP_BASE_HREF } from '@angular/common';
import { DeviceDetectorModule } from 'ngx-device-detector';
import { DesktopTrackRequestComponent } from './desktop-track-request/desktop-track-request.component';
import { ResponsiveService } from './responsive.service';
import { EmailupdateComponent } from './emailupdate/emailupdate.component';
import { UserIdleModule } from 'angular-user-idle';
//create routing for all user pages
const mobileRoutes = [
  { path: '', component: DesktopLoginComponent },
  { path: 'login', component: DesktopLoginComponent, data: { depth: 'login' } },
  { path: 'home', component: DesktophomeComponent,canActivate: [AuthGuard], data: { depth: 'home' } },
]

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    OtpComponent,
    UpdateProfileComponent,
    FeedbackComponent,
    SurrenderPolicyComponent,
    NomineeComponent,
    DesktopLoginComponent,
    DesktophomeComponent,
    DesktopTrackRequestComponent,
    EmailupdateComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot(mobileRoutes, { scrollPositionRestoration: 'top' }),
    DeviceDetectorModule.forRoot(),
    HttpModule,
    HttpClientModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    MzNavbarModule,
    MzSidenavModule,
    MzButtonModule,
    MzTextareaModule,
    MzDropdownModule,
    MzCardModule,
    MzCollapsibleModule,
    MzCheckboxModule,
    MzDatepickerModule,
    MzSelectModule,
    MzModalModule,
    MzBadgeModule,MzToastModule, 
    SlickCarouselModule,
    AngularDraggableModule,
    LottieAnimationViewModule.forRoot(),UserIdleModule.forRoot({idle: 1500, timeout: 300, ping: 1}),
    ServiceWorkerModule.register('/ngsw-worker.js', { enabled: true })
  ],
  exports: [],
  providers: [HeaderComponent,ApiService,ResponsiveService, { provide: APP_BASE_HREF, useValue : '' }],
  bootstrap: [AppComponent]
})
export class AppModule {
  public constructor(private router: Router) {
  }
}
