import { TestBed, async } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppComponent } from './app.component';
import { ResponsiveService } from './responsive.service';
import { ApiService } from './api/api.service';
import { AppRoutingModule } from './app-routing.module';
import { APP_BASE_HREF } from '@angular/common';
import { HttpModule,Http } from '@angular/http';
import { AngularDraggableModule } from 'angular2-draggable';
import { FormsModule ,ReactiveFormsModule} from '@angular/forms';
import { MzNavbarModule, MzSidenavModule, MzButtonModule, MzDropdownModule, MzToastModule, MzCardModule, MzBadgeModule, MzCheckboxModule, MzTextareaModule, MzSelectModule, MzDatepickerModule, MzCollapsibleModule, MzModalModule } from 'ngx-materialize';
import { DeviceDetectorService } from 'ngx-device-detector';
import { HeaderComponent } from './header/header.component';
import { SwUpdate } from '@angular/service-worker';
import { ServiceWorkerModule } from '@angular/service-worker';

ServiceWorkerModule.register('../ngsw-worker.js', { enabled: false })

describe('AppComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        MzNavbarModule,
        MzSidenavModule,
        MzButtonModule,
        MzTextareaModule,
        MzDropdownModule,
        MzCardModule,
        MzCollapsibleModule,
        MzCheckboxModule,
        MzDatepickerModule,
        MzSelectModule,
        MzModalModule,
        MzBadgeModule,
        MzToastModule,
        AppRoutingModule,
        HttpModule,
         AngularDraggableModule ,
           FormsModule,
    ReactiveFormsModule,
    ServiceWorkerModule.register('../ngsw-worker.js', { enabled: false }),
      ],
      declarations: [
        AppComponent,
        HeaderComponent
      ],
      providers: [ResponsiveService, MzToastModule, SwUpdate, ApiService, DeviceDetectorService, { provide: APP_BASE_HREF, useValue: '/' }]
    }).compileComponents();
    ResponsiveService
  }));

  it('should create the app', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  });


});
