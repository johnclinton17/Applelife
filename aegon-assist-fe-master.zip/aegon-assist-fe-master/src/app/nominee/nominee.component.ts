/*
 * aegonlife - v1.0.0 - 2019
 * @author aegonlife Insurance
 * nominee.component.ts
 * Description: to add and update to nominee
 * Copyright (c) 2019 aegonlife Insurance
 */
import { Component, OnInit, Renderer2 } from '@angular/core';
import { ApiService } from './../api/api.service';
import { DesktophomeComponent } from '../desktophome/desktophome.component';
import { AppComponent } from '../app.component';
import Analytics from '@aws-amplify/analytics';

import * as moment from 'moment';
declare var $: any;
@Component({
  selector: 'app-nominee',
  templateUrl: './nominee.component.html'
})

export class NomineeComponent implements OnInit {
  constructor(private ApiService: ApiService, public home: DesktophomeComponent,private appComponent : AppComponent, private renderer: Renderer2) {
    this.renderer.addClass(document.body, 'otp');
  }
  public options: Pickadate.DateOptions = {
    format: 'dd-mmm-yyyy',
    formatSubmit: 'yyyy-mm-dd',
    selectYears: 100,
    max: new Date(moment().subtract(18, "years").format("MM-DD-YYYY")),
    today: ''
  };
  // animated veriable declearation
  public lottieConfig: Object;
  private anim: any;
  deleteErrorFlag = false;
  errorFlag = false;
  animationFlag = false;
  policynum: string;
  policyDetail: any;
  nominee = {  "partyId" : '',"gender": "","dateOfBirth": '', "mobile": '', "emailId": '', "relationOfNominee": '', "firstName": '',"lastName":'' , "age" :0 , "nominationPercentage" : 0 }
  dobErrorFlag = false;
  otpText: any = [];
  mobileNumber: any;
  errorMessage: any;

  // nominee object 
  nomineeobject = {
    policyNumber: '',
    nominees: []
  }
  userDetails;
  policyDetails;
  ngOnDestroy() {
    this.renderer.removeClass(document.body, 'otp');
  }
 
  key: any;
  ngOnInit() { 
    this.userDetails = this.home.userdata();
    this.policyDetails = this.home.policydata();
    this.nomineeobject.policyNumber = this.policyDetails.policyNumber;
    // get user deatail
    if(this.policyDetails.nominees[0]){
      this.nominee = this.policyDetails.nominees[0];
    }

   
    if (this.nominee.dateOfBirth == '' || this.nominee.dateOfBirth == null) {
      this.nominee.dateOfBirth = '';
    }
    else {
      this.nominee.dateOfBirth = moment(this.nominee.dateOfBirth).format('YYYY-MM-DD');
    }
    // encrypt the policy number
  }

  submit() {
    this.nomineeobject.nominees = [];
    this.appComponent.loaderfunction(true);
    this.dobErrorFlag = false;
    var years = moment().diff(this.nominee.dateOfBirth, 'year');
    this.nominee.age = years;
    this.nominee.nominationPercentage = 100;
    if(this.nominee && (this.nominee.relationOfNominee =='HUSBAND'|| this.nominee.relationOfNominee == 'SON'|| this.nominee.relationOfNominee == 'FATHER' || this.nominee.relationOfNominee == 'BROTHER')){
      this.nominee.gender = 'Male'
    }
    else{
      this.nominee.gender = 'Female'
    }

    this.nomineeobject.nominees.push(this.nominee)
    this.ApiService.apirequest('/endorsements/nominees', this.nomineeobject).subscribe(data => {
       let response = data.json();
      if (response.status) {
         this.home.setrequestId(response.requestId);
        localStorage.setItem('event', 'nominee');
      Analytics.record({ name: 'nominee_success', attributes: { mobile: localStorage.getItem('visit') } });
         this.ApiService.destroySuccess(2500).then(() => {  this.home.setFlag('feedback') });
      }
      else {
        this.errorMessage = data.json().message;
        this.deleteErrorFlag = true;
           Analytics.record({ name: 'nominee_failed', attributes: { mobile: localStorage.getItem('visit') } });
      }
      this.appComponent.loaderfunction(false);
    })
  }
 
  // only number will accept
  validateNumber(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  // only number will accepet
  onlyNumber(event): boolean {
    return this.ApiService.onlyNumber(event);
  }
}
